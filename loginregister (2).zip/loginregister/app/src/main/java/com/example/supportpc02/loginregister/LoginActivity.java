package com.example.supportpc02.loginregister;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.support.v7.widget.AppCompatDrawableManager.get;

public class LoginActivity extends AppCompatActivity {

    private EditText mUsername, mUserpasswd;
    private Button mLogin;
    private TextView mRegister;
    private String name, password, spName, spPass;
    private SharedPreferences mSharedPreferences;
    public static final String PREFERENCE = "preference";
    public static final String PREF_NAME = "name";
    public static final String PREF_PASSWD = "passwd";

    //    public static final String PREF_SKIP_LOGIN = "skip_login";
//    String s = EditText.getText.toString;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mSharedPreferences = getSharedPreferences(PREFERENCE, Context.MODE_PRIVATE);
//        if (mSharedPreferences.contains(PREF_SKIP_LOGIN)) {
//            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
//            startActivity(intent);
//            finish();
//        } else {
        mUsername = (EditText) findViewById(R.id.user_name);
        mUserpasswd = (EditText) findViewById(R.id.user_passwd);
        mLogin = (Button) findViewById(R.id.loginBtn);
        mRegister = (TextView) findViewById(R.id.register);

        final AppSharedPref sharedPref = new AppSharedPref(this);

        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validUserData()) {

                    // do the comparing here between login n register
//                        ====================================================
//                    if(mUsername.equals(sharedPref.get(PREF_NAME)))
                    spName = sharedPref.get(PREF_NAME);
                    spPass = sharedPref.get(PREF_PASSWD);
                    if (name.equals(spName) && password.equals(spPass))

//                    ===========================================
                    {
//                        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
//                            mEditor.putString(PREF_SKIP_LOGIN,"skip");
//                        mEditor.apply();
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), "Unable to Login Plz Register !!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Unable to Login Plz Enter Valid Data !!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean validUserData() {
        name = mUsername.getText().toString().trim();
        password = mUserpasswd.getText().toString().trim();
        return !(name.isEmpty() || password.isEmpty());
    }
}