package com.example.supportpc02.loginregister;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {
//naming convention= camel style
//    for value Name => name == userName
    private EditText mName,mPasswd;
    private Button mRegisterBtn;
    private String name,password;
    public static final String PREFERENCE= "preference";
    public static final String PREF_NAME = "name";
    public static final String PREF_PASSWD = "passwd";
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mName = (EditText)findViewById(R.id.name);
        mPasswd = (EditText)findViewById(R.id.passwd);
        mRegisterBtn = (Button)findViewById(R.id.registerBtn);

        final AppSharedPref sharedPref = new AppSharedPref(this);
        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validUserData()){

                    sharedPref.set(PREF_NAME, name);
                    sharedPref.set(PREF_PASSWD, password);
                    finish();
                }
            }
        });
    }

    private boolean validUserData() {
        name = mName.getText().toString().trim();
        password = mPasswd.getText().toString().trim();
        return !(name.isEmpty() || password.isEmpty());
    }
}